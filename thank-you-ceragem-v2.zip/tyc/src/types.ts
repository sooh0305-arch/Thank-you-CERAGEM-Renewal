export type Role = 'user' | 'admin'

export interface User {
  id: string
  empNo: string
  name: string
  dept: string
  role: Role
  password: string
  mustChangePassword: boolean
  active: boolean
}

export interface Praise {
  id: string
  senderId: string
  receiverId: string
  valueNo: number // 1~7
  message: string
  points: number
  createdAt: string // ISO
  hidden: boolean
  readByReceiver: boolean
}

export type ExchangeStatus = '대기' | '승인' | '반려' | '지급완료'

export interface Exchange {
  id: string
  userId: string
  points: number
  status: ExchangeStatus
  requestedAt: string
  processedAt?: string
}

export interface AdminLog {
  id: string
  action: string
  at: string
  by: string
}

export interface CeraValue {
  no: number
  title: string
  short: string
  desc: string
}

export const CERA_VALUES: CeraValue[] = [
  { no: 1, title: '고객 관점', short: '고객의 눈으로', desc: '우리는 모든 업무를 수행함에 있어 철저하게 고객의 관점에서 생각하고 판단하고 행동한다.' },
  { no: 2, title: '문제의식', short: '가장 먼저 이야기하기', desc: '더 나은 고객가치를 위해 항상 문제의식을 갖고 업무에 임하며, 문제가 인지되면 그것이 무엇이든 가장 먼저 이야기한다.' },
  { no: 3, title: '심플한 해결책', short: '현장 중심으로 집요하게', desc: '문제의 본질에 집중하여 현장 중심의 심플한 해결책을 도출하고, 문제가 해결될 때까지 집요하게 추진하고 확인한다.' },
  { no: 4, title: '소통과 협업', short: '경계 없이 함께', desc: '최상의 성과를 위해 조직과 직무를 구분 짓지 않고 모든 동료들과 적극적으로 소통하고 협업한다.' },
  { no: 5, title: '도전과 존중', short: '실패를 두려워하지 않기', desc: '가치가 있는 일에는 실패를 두려워하지 않고 도전하며, 우리 모두는 이를 응원하고 돕고, 성과가 있는 동료를 진심으로 칭찬하고 존중한다.' },
  { no: 6, title: '학습과 육성', short: '배움을 나누기', desc: '최고의 조직이 되기 위해 우리 모두는 스스로 학습하고, 배움을 공유하며, 나보다 뛰어난 인재를 채용하고 육성한다.' },
  { no: 7, title: '정도경영', short: '데이터로 투명하게', desc: '항상 데이터 중심의 사실을 기반으로 이야기하고, 원칙과 기준에 따라 투명하게 업무를 수행함으로써 정도경영을 실천한다.' },
]

export const MONTHLY_GIVE = 5000
export const PER_PERSON_CAP = 1000
export const MIN_SEND = 100
export const STEP = 100
