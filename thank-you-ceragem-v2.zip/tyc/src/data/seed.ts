import type { User, Praise, Exchange } from '../types'

export const seedUsers: User[] = [
  { id: 'u1', empNo: '100001', name: '이동현', dept: '세라제머육성팀', role: 'admin', password: '1234', mustChangePassword: false, active: true },
  { id: 'u2', empNo: '100002', name: '김소영', dept: '세라제머육성팀', role: 'user', password: '0000', mustChangePassword: true, active: true },
  { id: 'u3', empNo: '100003', name: '백승휘', dept: '영업기획팀', role: 'user', password: '0000', mustChangePassword: true, active: true },
  { id: 'u4', empNo: '100004', name: '김우진', dept: '연구개발팀', role: 'user', password: '0000', mustChangePassword: true, active: true },
  { id: 'u5', empNo: '100005', name: '박명수', dept: '고객지원팀', role: 'user', password: '0000', mustChangePassword: true, active: true },
  { id: 'u6', empNo: '100006', name: '천상호', dept: '마케팅팀', role: 'user', password: '0000', mustChangePassword: true, active: true },
  { id: 'u7', empNo: '100007', name: '소은혜', dept: '인사팀', role: 'user', password: '0000', mustChangePassword: true, active: true },
  { id: 'u8', empNo: '100008', name: '정다운', dept: '재무팀', role: 'user', password: '0000', mustChangePassword: true, active: true },
]

function daysAgo(n: number): string {
  const d = new Date()
  d.setDate(d.getDate() - n)
  return d.toISOString()
}

export const seedPraises: Praise[] = [
  { id: 'p1', senderId: 'u5', receiverId: 'u1', valueNo: 4, message: '갑작스러운 전사 교육 일정 변경에도 밤늦게까지 함께 조율해주신 덕분에 무사히 진행할 수 있었습니다. 진심으로 감사드립니다.', points: 300, createdAt: daysAgo(1), hidden: false, readByReceiver: false },
  { id: 'p2', senderId: 'u6', receiverId: 'u1', valueNo: 6, message: 'CERA Agent 교육에서 배운 내용을 팀에 공유해주셔서 업무 자동화에 큰 도움이 되었습니다.', points: 200, createdAt: daysAgo(2), hidden: false, readByReceiver: false },
  { id: 'p3', senderId: 'u7', receiverId: 'u1', valueNo: 3, message: 'LMS 수료 현황 대시보드를 심플하게 정리해주신 덕분에 매달 반복되던 확인 업무가 사라졌어요!', points: 100, createdAt: daysAgo(3), hidden: false, readByReceiver: false },
  { id: 'p4', senderId: 'u1', receiverId: 'u2', valueNo: 4, message: '개인이 빛나는 것보다 동료를 더욱 빛나게 하려는 모습이 세라제머십 4번, 최상의 성과를 위한 협업 그 자체였습니다.', points: 300, createdAt: daysAgo(4), hidden: false, readByReceiver: true },
  { id: 'p5', senderId: 'u4', receiverId: 'u3', valueNo: 4, message: '예상치 못한 상황에서도 망설임 없이 함께 도와주신 덕분에 빠르게 상황을 정리할 수 있었습니다.', points: 200, createdAt: daysAgo(5), hidden: false, readByReceiver: true },
  { id: 'p6', senderId: 'u3', receiverId: 'u4', valueNo: 5, message: '아무도 시도하지 않았던 방식에 먼저 도전하시고, 실패 과정까지 투명하게 공유해주셔서 팀 전체가 배웠습니다.', points: 500, createdAt: daysAgo(6), hidden: false, readByReceiver: true },
  { id: 'p7', senderId: 'u2', receiverId: 'u5', valueNo: 1, message: '고객 불만 응대에서 끝까지 고객 입장에서 생각하시는 모습을 보고 많이 배웠습니다.', points: 300, createdAt: daysAgo(8), hidden: false, readByReceiver: true },
  { id: 'p8', senderId: 'u8', receiverId: 'u6', valueNo: 7, message: '캠페인 성과를 데이터 기반으로 투명하게 공유해주셔서 의사결정이 훨씬 빨라졌습니다.', points: 200, createdAt: daysAgo(9), hidden: false, readByReceiver: true },
  { id: 'p9', senderId: 'u5', receiverId: 'u7', valueNo: 2, message: '채용 프로세스의 문제를 가장 먼저 공유하고 개선안을 제안해주셔서 감사합니다.', points: 400, createdAt: daysAgo(12), hidden: false, readByReceiver: true },
  { id: 'p10', senderId: 'u6', receiverId: 'u8', valueNo: 3, message: '복잡했던 정산 프로세스를 한 장으로 정리해주신 덕분에 전 팀이 편해졌습니다.', points: 300, createdAt: daysAgo(15), hidden: false, readByReceiver: true },
  { id: 'p11', senderId: 'u7', receiverId: 'u2', valueNo: 6, message: '신입 온보딩 자료를 자발적으로 업데이트해주셔서 육성 문화에 큰 힘이 됩니다.', points: 200, createdAt: daysAgo(18), hidden: false, readByReceiver: true },
  { id: 'p12', senderId: 'u4', receiverId: 'u1', valueNo: 5, message: 'AI 영상 공모전 도전 자체가 팀에 좋은 자극이 되었습니다. 응원합니다!', points: 100, createdAt: daysAgo(20), hidden: false, readByReceiver: true },
]

export const seedExchanges: Exchange[] = [
  { id: 'e1', userId: 'u3', points: 200, status: '지급완료', requestedAt: daysAgo(10), processedAt: daysAgo(7) },
  { id: 'e2', userId: 'u1', points: 100, status: '대기', requestedAt: daysAgo(1) },
]
