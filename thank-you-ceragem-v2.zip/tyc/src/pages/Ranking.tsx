import { useMemo } from 'react'
import { useDB, honorThisQuarter, quarterLabel, quarterEndsInDays } from '../store/store'
import { Reveal, fmt } from '../components/common'

export default function Ranking() {
  const db = useDB()
  const ranked = useMemo(() =>
    db.users.filter(u => u.active)
      .map(u => ({ u, pt: honorThisQuarter(u.id) }))
      .sort((a, b) => b.pt - a.pt)
      .slice(0, 10),
    [db.users, db.praises])

  const [first, ...others] = ranked
  const days = quarterEndsInDays()

  return (
    <section className="section" style={{ paddingTop: 56 }}>
      <div className="wrap">
        <span className="eyebrow">Thank you CERAGEM Award</span>
        <h1 className="display" style={{ fontSize: 'clamp(30px,4.6vw,48px)', marginTop: 10 }}>{quarterLabel()} 랭킹</h1>
        <p className="muted" style={{ marginTop: 8 }}>분기 누적 포인트 상위 2명이 '땡큐 세라제머'로 선정되어 각 100만원을 시상합니다. 현금 교환과 무관하게 누적됩니다.</p>

        <div className="countdown-band" style={{ marginTop: 28 }}>
          <div>🏆 이번 분기 마감까지 <span className="big">D-{days}</span></div>
          <div>상위 2명 · 인당 1,000,000원</div>
        </div>

        {first && (
          <Reveal>
            <div className="rank-hero" style={{ marginTop: 20 }}>
              <div className="crown">👑</div>
              <div>
                <div style={{ fontSize: 13, fontWeight: 800, letterSpacing: '0.14em', color: 'var(--gold)' }}>CURRENT NO.1</div>
                <div className="nm">{first.u.name}</div>
                <div style={{ opacity: 0.7, fontWeight: 700 }}>{first.u.dept}</div>
              </div>
              <div className="pt">{fmt(first.pt)}P</div>
            </div>
          </Reveal>
        )}

        <div className="list-plain" style={{ marginTop: 20 }}>
          {others.map((r, i) => (
            <div className={`rank-row ${i === 0 ? 'top' : ''}`} key={r.u.id}>
              <div className="pos">{i + 2}</div>
              <div className="avatar">{r.u.name[0]}</div>
              <div>
                <div style={{ fontWeight: 800 }}>{r.u.name} {i === 0 && <span className="value-tag" style={{ marginLeft: 6 }}>시상권</span>}</div>
                <div className="muted" style={{ fontSize: 13 }}>{r.u.dept}</div>
              </div>
              <div className="pt-chip">{fmt(r.pt)}P</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
