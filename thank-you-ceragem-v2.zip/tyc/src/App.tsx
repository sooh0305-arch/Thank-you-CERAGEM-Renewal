import { HashRouter, Routes, Route, Navigate, useLocation } from 'react-router-dom'
import { useEffect } from 'react'
import { useDB } from './store/store'
import { TopNav, SiteFooter } from './components/common'
import Login from './pages/Login'
import Home from './pages/Home'
import Send from './pages/Send'
import Feed from './pages/Feed'
import History from './pages/History'
import Ranking from './pages/Ranking'
import Guide from './pages/Guide'
import Admin from './pages/Admin'

function ScrollTop() {
  const { pathname } = useLocation()
  useEffect(() => { window.scrollTo(0, 0) }, [pathname])
  return null
}

function Protected({ children, admin = false }: { children: React.ReactNode; admin?: boolean }) {
  const db = useDB()
  const me = db.users.find(u => u.id === db.sessionUserId)
  if (!me || me.mustChangePassword) return <Navigate to="/login" replace />
  if (admin && me.role !== 'admin') return <Navigate to="/" replace />
  return (
    <>
      <TopNav />
      <main>{children}</main>
      <SiteFooter />
    </>
  )
}

export default function App() {
  return (
    <HashRouter>
      <ScrollTop />
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/" element={<Protected><Home /></Protected>} />
        <Route path="/send" element={<Protected><Send /></Protected>} />
        <Route path="/feed" element={<Protected><Feed /></Protected>} />
        <Route path="/history" element={<Protected><History /></Protected>} />
        <Route path="/ranking" element={<Protected><Ranking /></Protected>} />
        <Route path="/guide" element={<Protected><Guide /></Protected>} />
        <Route path="/admin" element={<Protected admin><Admin /></Protected>} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </HashRouter>
  )
}
