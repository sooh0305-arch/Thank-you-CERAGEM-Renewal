import { useSyncExternalStore } from 'react'
import type { User, Praise, Exchange, AdminLog } from '../types'
import { MONTHLY_GIVE, PER_PERSON_CAP } from '../types'
import { seedUsers, seedPraises, seedExchanges } from '../data/seed'

const KEY = 'tyc-v2'

/* localStorage가 차단된 환경(샌드박스 미리보기 등)에서는 메모리로 폴백 */
const memStore = new Map<string, string>()
const storage = {
  get(k: string): string | null {
    try { return window.localStorage.getItem(k) } catch { return memStore.get(k) ?? null }
  },
  set(k: string, v: string) {
    try { window.localStorage.setItem(k, v) } catch { memStore.set(k, v) }
  },
  remove(k: string) {
    try { window.localStorage.removeItem(k) } catch { memStore.delete(k) }
  },
}

interface DB {
  users: User[]
  praises: Praise[]
  exchanges: Exchange[]
  logs: AdminLog[]
  sessionUserId: string | null
}

function load(): DB {
  try {
    const raw = storage.get(KEY)
    if (raw) return JSON.parse(raw) as DB
  } catch { /* ignore */ }
  return { users: seedUsers, praises: seedPraises, exchanges: seedExchanges, logs: [], sessionUserId: null }
}

let db: DB = load()
const listeners = new Set<() => void>()

function commit() {
  db = { ...db }
  storage.set(KEY, JSON.stringify(db))
  listeners.forEach(l => l())
}

export function useDB(): DB {
  return useSyncExternalStore(
    (cb) => { listeners.add(cb); return () => listeners.delete(cb) },
    () => db,
  )
}

export const uid = () => Math.random().toString(36).slice(2, 10)

/* ---------- date helpers ---------- */
export function sameMonth(iso: string, ref = new Date()): boolean {
  const d = new Date(iso)
  return d.getFullYear() === ref.getFullYear() && d.getMonth() === ref.getMonth()
}
export function sameQuarter(iso: string, ref = new Date()): boolean {
  const d = new Date(iso)
  return d.getFullYear() === ref.getFullYear() && Math.floor(d.getMonth() / 3) === Math.floor(ref.getMonth() / 3)
}
export function quarterLabel(ref = new Date()): string {
  return `${ref.getFullYear()}년 ${Math.floor(ref.getMonth() / 3) + 1}분기`
}
export function quarterEndsInDays(ref = new Date()): number {
  const q = Math.floor(ref.getMonth() / 3)
  const end = new Date(ref.getFullYear(), q * 3 + 3, 0)
  return Math.max(0, Math.ceil((end.getTime() - ref.getTime()) / 86400000))
}

/* ---------- ledger-style point math (never store balances) ---------- */
export function givenThisMonth(userId: string): number {
  return db.praises.filter(p => p.senderId === userId && sameMonth(p.createdAt)).reduce((s, p) => s + p.points, 0)
}
export function giveRemaining(userId: string): number {
  return MONTHLY_GIVE - givenThisMonth(userId)
}
export function givenToPersonThisMonth(senderId: string, receiverId: string): number {
  return db.praises.filter(p => p.senderId === senderId && p.receiverId === receiverId && sameMonth(p.createdAt)).reduce((s, p) => s + p.points, 0)
}
export function receivedTotal(userId: string): number {
  return db.praises.filter(p => p.receiverId === userId).reduce((s, p) => s + p.points, 0)
}
export function receivedThisMonth(userId: string): number {
  return db.praises.filter(p => p.receiverId === userId && sameMonth(p.createdAt)).reduce((s, p) => s + p.points, 0)
}
/** 아너 포인트: 분기 누적, 교환과 무관 */
export function honorThisQuarter(userId: string): number {
  return db.praises.filter(p => p.receiverId === userId && sameQuarter(p.createdAt)).reduce((s, p) => s + p.points, 0)
}
/** 리워드 포인트: 받은 전체 - 교환(반려 제외) */
export function rewardBalance(userId: string): number {
  const spent = db.exchanges.filter(e => e.userId === userId && e.status !== '반려').reduce((s, e) => s + e.points, 0)
  return receivedTotal(userId) - spent
}

/* ---------- actions ---------- */
export function login(empNoOrName: string, password: string): { ok: boolean; error?: string } {
  const u = db.users.find(x => (x.empNo === empNoOrName || x.name === empNoOrName) && x.active)
  if (!u) return { ok: false, error: '사용자를 찾을 수 없습니다. 사번 또는 이름을 확인해주세요.' }
  if (u.password !== password) return { ok: false, error: '비밀번호가 일치하지 않습니다.' }
  db.sessionUserId = u.id
  commit()
  return { ok: true }
}
export function logout() { db.sessionUserId = null; commit() }

export function changePassword(userId: string, newPw: string) {
  db.users = db.users.map(u => u.id === userId ? { ...u, password: newPw, mustChangePassword: false } : u)
  commit()
}

export function sendPraise(senderId: string, receiverId: string, valueNo: number, message: string, points: number): { ok: boolean; error?: string } {
  if (senderId === receiverId) return { ok: false, error: '자기 자신에게는 보낼 수 없습니다.' }
  if (message.trim().length < 10) return { ok: false, error: '메시지를 10자 이상 작성해주세요.' }
  if (points > giveRemaining(senderId)) return { ok: false, error: '이번 달 남은 포인트가 부족합니다.' }
  if (givenToPersonThisMonth(senderId, receiverId) + points > PER_PERSON_CAP) {
    return { ok: false, error: `한 사람에게는 한 달에 최대 ${PER_PERSON_CAP.toLocaleString()}P까지 보낼 수 있습니다.` }
  }
  db.praises = [{ id: uid(), senderId, receiverId, valueNo, message: message.trim(), points, createdAt: new Date().toISOString(), hidden: false, readByReceiver: false }, ...db.praises]
  commit()
  return { ok: true }
}

export function markPraiseRead(praiseId: string) {
  db.praises = db.praises.map(p => p.id === praiseId ? { ...p, readByReceiver: true } : p)
  commit()
}
export function markAllRead(userId: string) {
  db.praises = db.praises.map(p => p.receiverId === userId ? { ...p, readByReceiver: true } : p)
  commit()
}

export function requestExchange(userId: string, points: number): { ok: boolean; error?: string } {
  if (points <= 0) return { ok: false, error: '교환할 포인트를 입력해주세요.' }
  if (points > rewardBalance(userId)) return { ok: false, error: '교환 가능한 포인트가 부족합니다.' }
  db.exchanges = [{ id: uid(), userId, points, status: '대기', requestedAt: new Date().toISOString() }, ...db.exchanges]
  commit()
  return { ok: true }
}

/* ---------- admin actions ---------- */
function log(action: string, by: string) {
  db.logs = [{ id: uid(), action, at: new Date().toISOString(), by }, ...db.logs]
}
export function adminResetPassword(adminId: string, userId: string) {
  db.users = db.users.map(u => u.id === userId ? { ...u, password: '0000', mustChangePassword: true } : u)
  const target = db.users.find(u => u.id === userId)
  log(`비밀번호 초기화: ${target?.name}`, adminId)
  commit()
}
export function adminToggleActive(adminId: string, userId: string) {
  db.users = db.users.map(u => u.id === userId ? { ...u, active: !u.active } : u)
  const target = db.users.find(u => u.id === userId)
  log(`계정 ${target?.active ? '활성화' : '비활성화'}: ${target?.name}`, adminId)
  commit()
}
export function adminAddUser(adminId: string, name: string, dept: string, empNo: string) {
  db.users = [...db.users, { id: uid(), empNo, name, dept, role: 'user', password: '0000', mustChangePassword: true, active: true }]
  log(`사용자 등록: ${name}`, adminId)
  commit()
}
export function adminTogglePraiseHidden(adminId: string, praiseId: string) {
  db.praises = db.praises.map(p => p.id === praiseId ? { ...p, hidden: !p.hidden } : p)
  log(`칭찬 공개상태 변경: ${praiseId}`, adminId)
  commit()
}
export function adminSetExchangeStatus(adminId: string, exchangeId: string, status: Exchange['status']) {
  db.exchanges = db.exchanges.map(e => e.id === exchangeId ? { ...e, status, processedAt: new Date().toISOString() } : e)
  log(`포인트 교환 ${status} 처리`, adminId)
  commit()
}
export function adminMonthlyReset(adminId: string) {
  log('월별 기브 포인트 5,000P 일괄 초기화 실행', adminId)
  commit()
}
export function adminCloseQuarter(adminId: string, winners: string[]) {
  log(`분기 마감 · 땡큐 세라제머 선정: ${winners.join(', ')}`, adminId)
  commit()
}
export function resetDemo() {
  storage.remove(KEY)
  db = load()
  commit()
}
