import { Link } from 'react-router-dom'
import { CERA_VALUES } from '../types'
import { Reveal } from '../components/common'

export default function Guide() {
  return (
    <>
      <section className="section" style={{ paddingTop: 56, paddingBottom: 40 }}>
        <div className="wrap">
          <span className="eyebrow">How it works</span>
          <h1 className="display" style={{ fontSize: 'clamp(30px,4.6vw,48px)', marginTop: 10 }}>1분이면 충분한 이용 가이드</h1>
        </div>
      </section>

      {/* point rules */}
      <section className="section-tight">
        <div className="wrap">
          <h2 className="display" style={{ fontSize: 26, marginBottom: 18 }}>포인트, 딱 4가지만 기억하세요</h2>
          <div className="rule-grid">
            <div className="rule-card"><div className="n">5,000P</div><b>매달 새로 채워지는 '보내기 포인트'</b><p>매월 1일 5,000P가 지급돼요. 쓰지 않은 포인트는 이월되지 않고 소멸됩니다.</p></div>
            <div className="rule-card"><div className="n">1,000P</div><b>한 사람에게 보낼 수 있는 월 한도</b><p>한 달 동안 같은 동료에게는 최대 1,000P까지만 보낼 수 있어요. 마음을 넓게 나눠주세요.</p></div>
            <div className="rule-card"><div className="n">1P = 1원</div><b>받은 포인트는 현금으로</b><p>받은 칭찬 포인트는 현금으로 교환 신청할 수 있어요. 관리자 승인 후 지급됩니다.</p></div>
            <div className="rule-card"><div className="n">100만원</div><b>분기 시상 '땡큐 세라제머'</b><p>분기 누적 포인트 상위 2명에게 각 100만원! 현금으로 교환해도 누적 포인트는 줄지 않아요.</p></div>
          </div>
        </div>
      </section>

      {/* 7 values, full sections */}
      <section className="section">
        <div className="wrap">
          <span className="eyebrow">The 7 CERAGEMERSHIP</span>
          <h2 className="display" style={{ fontSize: 'clamp(26px,4vw,38px)', marginBottom: 26, marginTop: 8 }}>칭찬의 언어, 세라제머십 7</h2>
          <div>
            {CERA_VALUES.map(v => (
              <Reveal key={v.no}>
                <div className="guide-value">
                  <div className="no">{String(v.no).padStart(2, '0')}</div>
                  <div>
                    <div className="eyebrow" style={{ color: 'inherit', opacity: 0.7 }}>{v.short}</div>
                    <h3>{v.title}</h3>
                    <p>{v.desc}</p>
                    <div style={{ marginTop: 18 }}>
                      <Link className="btn btn-ghost btn-sm" style={{ borderColor: 'currentColor' }} to={`/send?value=${v.no}`}>이 가치로 칭찬 보내기</Link>
                    </div>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="section" style={{ paddingTop: 0 }}>
        <div className="wrap" style={{ maxWidth: 800 }}>
          <h2 className="display" style={{ fontSize: 26, marginBottom: 18 }}>자주 묻는 질문</h2>
          <details className="faq"><summary>제가 보낸 칭찬은 익명인가요?</summary><div className="a">네. 전체 피드와 받는 분의 히스토리에는 보낸 사람이 표시되지 않아요. 다만 운영을 위해 관리자는 발신자를 확인할 수 있습니다.</div></details>
          <details className="faq"><summary>포인트를 현금으로 바꾸면 분기 랭킹에서 불리해지나요?</summary><div className="a">아니요. 분기 시상용 누적 포인트와 현금 교환용 리워드 포인트는 별도로 계산돼요. 1,000P를 현금으로 교환해도 누적 포인트는 그대로 1,000P 유지됩니다.</div></details>
          <details className="faq"><summary>이번 달에 다 못 쓴 보내기 포인트는 어떻게 되나요?</summary><div className="a">이월되지 않고 소멸돼요. 매달 새로 5,000P가 채워지니, 그때그때 고마운 마음을 표현해주세요.</div></details>
          <details className="faq"><summary>비밀번호를 잊어버렸어요.</summary><div className="a">세라제머육성팀(관리자)에게 초기화를 요청하면 0000으로 초기화되고, 다음 로그인 때 새 비밀번호를 설정하게 됩니다.</div></details>
          <details className="faq"><summary>땡큐 세라제머 선정 기준이 궁금해요.</summary><div className="a">분기 동안 받은 누적 포인트 상위 2명이 선정되며, 인당 100만원을 시상해요. 세부 기준(동점자 처리 등)은 운영 공지를 확인해주세요.</div></details>
        </div>
      </section>
    </>
  )
}
