import { useMemo, useState } from 'react'
import { useDB, sameMonth } from '../store/store'
import { CERA_VALUES } from '../types'
import { Reveal, ValueTag, fmt, fmtDate } from '../components/common'

export default function Feed() {
  const db = useDB()
  const [filter, setFilter] = useState(0) // 0 = all
  const [q, setQ] = useState('')

  const visible = useMemo(() => {
    return db.praises
      .filter(p => !p.hidden)
      .filter(p => filter === 0 || p.valueNo === filter)
      .filter(p => {
        if (!q.trim()) return true
        const r = db.users.find(u => u.id === p.receiverId)
        return (r?.name ?? '').includes(q.trim())
      })
      .sort((a, b) => b.createdAt.localeCompare(a.createdAt))
  }, [db.praises, filter, q])

  const [heroP, ...rest] = visible
  const monthCount = db.praises.filter(p => sameMonth(p.createdAt) && !p.hidden).length
  const userOf = (id: string) => db.users.find(u => u.id === id)

  return (
    <>
      <section className="section" style={{ paddingTop: 56, paddingBottom: 48 }}>
        <div className="wrap">
          <span className="eyebrow">Live Praise Feed</span>
          <h1 className="display" style={{ fontSize: 'clamp(30px,4.6vw,48px)', marginTop: 10 }}>지금, 서로에게 오가는 마음</h1>
          <p className="muted" style={{ marginTop: 8 }}>보낸 사람은 표시되지 않아요. 마음만 도착합니다.</p>

          <div className="filter-row">
            <button className={`chip ${filter === 0 ? 'on' : ''}`} onClick={() => setFilter(0)}>전체</button>
            {CERA_VALUES.map(v => (
              <button key={v.no} className={`chip ${filter === v.no ? 'on' : ''}`} onClick={() => setFilter(v.no)}>
                {String(v.no).padStart(2, '0')} {v.title}
              </button>
            ))}
            <input className="search-input" placeholder="받은 동료 이름 검색" value={q} onChange={e => setQ(e.target.value)} />
          </div>

          {heroP ? (
            <Reveal className="feed-hero-card-wrap">
              <div className="feed-hero-card" style={{ marginTop: 28 }}>
                <span className="eyebrow">Latest Highlight</span>
                <div className="q" style={{ marginTop: 12 }}>“{heroP.message}”</div>
                <div className="who">
                  <div className="avatar">{userOf(heroP.receiverId)?.name[0]}</div>
                  <div>
                    <div style={{ fontWeight: 800 }}>{userOf(heroP.receiverId)?.name} <span className="muted" style={{ fontWeight: 600, fontSize: 13 }}>{userOf(heroP.receiverId)?.dept}</span></div>
                    <div style={{ display: 'flex', gap: 10, alignItems: 'center', marginTop: 4 }}>
                      <ValueTag no={heroP.valueNo} />
                      <span className="pt-chip">+{fmt(heroP.points)}P</span>
                      <span className="muted" style={{ fontSize: 12.5 }}>{fmtDate(heroP.createdAt)} · 익명의 동료</span>
                    </div>
                  </div>
                </div>
              </div>
            </Reveal>
          ) : (
            <div className="feed-hero-card" style={{ marginTop: 28, textAlign: 'center' }}>
              <p className="muted">조건에 맞는 칭찬이 아직 없어요. 첫 번째 칭찬의 주인공이 되어보세요!</p>
            </div>
          )}

          <div className="feed-list">
            {rest.map(p => {
              const r = userOf(p.receiverId)
              return (
                <div className="feed-row" key={p.id}>
                  <div className="avatar gold">{r?.name[0]}</div>
                  <div>
                    <div className="msg">“{p.message}”</div>
                    <div className="meta">
                      <span className="name">{r?.name}</span>
                      <span className="muted" style={{ fontSize: 13 }}>{r?.dept}</span>
                      <ValueTag no={p.valueNo} />
                      <span className="date">{fmtDate(p.createdAt)} · 익명의 동료</span>
                    </div>
                  </div>
                  <div className="pt-chip">+{fmt(p.points)}P</div>
                </div>
              )
            })}
          </div>
        </div>
      </section>

      <section className="stat-band">
        <div className="wrap">
          <div className="n">{fmt(monthCount)}</div>
          <div className="l">이번 달 우리가 서로에게 보낸 칭찬</div>
        </div>
      </section>
    </>
  )
}
