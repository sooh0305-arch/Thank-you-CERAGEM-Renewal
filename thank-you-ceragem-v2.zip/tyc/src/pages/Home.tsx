import { useMemo, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useDB, giveRemaining, sameMonth, honorThisQuarter, quarterLabel } from '../store/store'
import { CERA_VALUES } from '../types'
import { Reveal, fmt, valueOf } from '../components/common'

export default function Home() {
  const db = useDB()
  const nav = useNavigate()
  const me = db.users.find(u => u.id === db.sessionUserId)!
  const [vi, setVi] = useState(0)
  const v = CERA_VALUES[vi]

  const monthPraises = db.praises.filter(p => sameMonth(p.createdAt) && !p.hidden)
  const monthCount = monthPraises.length
  const remaining = giveRemaining(me.id)

  const topValue = useMemo(() => {
    const counts = new Map<number, number>()
    monthPraises.forEach(p => counts.set(p.valueNo, (counts.get(p.valueNo) ?? 0) + 1))
    let best = 4, bestN = -1
    counts.forEach((n, no) => { if (n > bestN) { best = no; bestN = n } })
    return valueOf(best)
  }, [db.praises])

  const quarterTop = useMemo(() => {
    const ranked = db.users.filter(u => u.active).map(u => ({ u, pt: honorThisQuarter(u.id) })).sort((a, b) => b.pt - a.pt)
    return ranked[0]
  }, [db.praises, db.users])

  return (
    <>
      {/* HERO — asymmetric, send panel styled like a purchase panel */}
      <section className="hero">
        <div className="wrap hero-grid">
          <div>
            <span className="eyebrow">Peer Recognition Platform</span>
            <h1 className="display" style={{ marginTop: 14 }}>
              고마운 마음,<br /><span className="accent">오늘 바로</span> 전하세요
            </h1>
            <p className="lead">
              세라제머십 7가지 가치로 동료를 칭찬하고 포인트를 선물하세요.
              받은 포인트는 현금처럼, 쌓인 마음은 분기 시상으로 이어집니다.
            </p>
            <div className="hero-stats">
              <div><div className="n">{fmt(monthCount)}</div><div className="l">이번 달 오간 칭찬</div></div>
              <div><div className="n">{topValue.title}</div><div className="l">이달의 인기 가치</div></div>
              <div><div className="n">{fmt(remaining)}P</div><div className="l">내가 보낼 수 있는 포인트</div></div>
            </div>
          </div>

          <div className="send-panel">
            <h3>칭찬 보내기</h3>
            <p className="sub">상품을 담듯, 마음을 담아 보내면 됩니다.</p>
            <div className="field">
              <label>세라제머십 가치</label>
              <select defaultValue={4} id="home-value">
                {CERA_VALUES.map(cv => <option key={cv.no} value={cv.no}>{String(cv.no).padStart(2, '0')} · {cv.title}</option>)}
              </select>
            </div>
            <div className="field">
              <label>받는 동료</label>
              <select id="home-receiver" defaultValue="">
                <option value="" disabled>동료를 선택하세요</option>
                {db.users.filter(u => u.active && u.id !== me.id).map(u => <option key={u.id} value={u.id}>{u.name} · {u.dept}</option>)}
              </select>
            </div>
            <div className="budget-bar">
              <div className="track"><div className="fill" style={{ width: `${(remaining / 5000) * 100}%` }} /></div>
              <div className="cap"><span>남은 보내기 포인트</span><span><b style={{ color: 'var(--red)' }}>{fmt(remaining)}P</b> / 5,000P</span></div>
            </div>
            <div style={{ marginTop: 18 }}>
              <button
                className="btn btn-primary btn-block"
                onClick={() => {
                  const val = (document.getElementById('home-value') as HTMLSelectElement).value
                  const rec = (document.getElementById('home-receiver') as HTMLSelectElement).value
                  nav(`/send?value=${val}${rec ? `&to=${rec}` : ''}`)
                }}
              >
                메시지 작성하러 가기 →
              </button>
            </div>
            <p className="hint">한 사람에게 월 최대 1,000P · 남은 포인트는 매월 소멸</p>
          </div>
        </div>
      </section>

      {/* BENEFIT ICON ROW */}
      <section className="section-tight" style={{ background: 'var(--white)', borderTop: '1.5px solid var(--line)', borderBottom: '1.5px solid var(--line)' }}>
        <div className="wrap">
          <Reveal>
            <div className="benefits">
              <div className="benefit"><div className="ic">💌</div><b>바로 도착</b><span>보내는 즉시 동료에게 알림</span></div>
              <div className="benefit"><div className="ic">🤫</div><b>익명 발송</b><span>피드에는 보낸 사람 비공개</span></div>
              <div className="benefit"><div className="ic">💰</div><b>현금 교환</b><span>받은 포인트 1P = 1원</span></div>
              <div className="benefit"><div className="ic">🏆</div><b>분기 시상</b><span>땡큐 세라제머 2명, 각 100만원</span></div>
            </div>
          </Reveal>
        </div>
      </section>

      {/* TYPOGRAPHIC BREAK — signature moment */}
      <section className="typo-break">
        <span className="spark" style={{ top: '16%', left: '8%' }}>✦</span>
        <span className="spark" style={{ bottom: '14%', right: '10%' }}>✦</span>
        <span className="spark" style={{ top: '58%', left: '20%', fontSize: 18 }}>✦</span>
        <div className="wrap">
          <div className="big">THANK YOU<br />MAKES US <em>BETTER</em></div>
          <div className="small">'고맙다'는 말을 가장 많이 듣는 파트너가 되는 길은, 서로에게 먼저 건네는 것부터.</div>
        </div>
      </section>

      {/* VALUE CAROUSEL */}
      <section className="section">
        <div className="wrap">
          <div className="carousel-head">
            <div>
              <span className="eyebrow">The 7 CERAGEMERSHIP</span>
              <h2 className="display">어떤 가치로 칭찬할까요?</h2>
            </div>
            <div className="arrows">
              <button className="arrow" aria-label="이전 가치" onClick={() => setVi(i => (i + 6) % 7)}>←</button>
              <button className="arrow" aria-label="다음 가치" onClick={() => setVi(i => (i + 1) % 7)}>→</button>
            </div>
          </div>
          <div className="value-stage">
            <div className="no">{String(v.no).padStart(2, '0')}</div>
            <div>
              <div className="short">{v.short}</div>
              <h3>{v.title}</h3>
              <p>{v.desc}</p>
              <div style={{ marginTop: 20 }}>
                <Link className="btn btn-ghost btn-sm" to={`/send?value=${v.no}`}>이 가치로 칭찬 보내기</Link>
              </div>
            </div>
          </div>
          <div className="value-dots">
            {CERA_VALUES.map((cv, i) => <button key={cv.no} className={i === vi ? 'on' : ''} aria-label={cv.title} onClick={() => setVi(i)} />)}
          </div>
        </div>
      </section>

      {/* COLOR BLOCK STRIP */}
      <section className="section-tight">
        <div className="wrap">
          <Reveal>
            <div className="block-strip">
              <Link to="/ranking" className="block red">
                <div><div className="tag">QUARTER RACE</div><h4>{quarterLabel()}<br />현재 1위 {quarterTop?.u.name ?? '-'}</h4></div>
                <div className="foot">누적 {fmt(quarterTop?.pt ?? 0)}P · 랭킹 보기 →</div>
              </Link>
              <Link to="/feed" className="block gold">
                <div><div className="tag">LIVE FEED</div><h4>지금 오가는<br />칭찬 읽어보기</h4></div>
                <div className="foot">이번 달 {fmt(monthCount)}건 · 피드 가기 →</div>
              </Link>
              <Link to="/guide" className="block inkb">
                <div><div className="tag">HOW IT WORKS</div><h4>포인트 제도,<br />1분 만에 이해하기</h4></div>
                <div className="foot">가이드 보기 →</div>
              </Link>
            </div>
          </Reveal>
        </div>
      </section>
    </>
  )
}
