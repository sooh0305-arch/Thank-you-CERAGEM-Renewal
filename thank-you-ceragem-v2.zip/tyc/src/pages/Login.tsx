import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useDB, login, changePassword } from '../store/store'

export default function Login() {
  const db = useDB()
  const nav = useNavigate()
  const [id, setId] = useState('')
  const [pw, setPw] = useState('')
  const [err, setErr] = useState('')
  const [newPw, setNewPw] = useState('')
  const [newPw2, setNewPw2] = useState('')

  const me = db.users.find(u => u.id === db.sessionUserId)
  const needChange = me?.mustChangePassword

  const submit = () => {
    const r = login(id.trim(), pw)
    if (!r.ok) { setErr(r.error!); return }
    setErr('')
  }
  const submitChange = () => {
    if (newPw.length < 4) { setErr('비밀번호는 4자 이상으로 설정해주세요.'); return }
    if (newPw === '0000') { setErr('초기 비밀번호(0000)는 사용할 수 없습니다.'); return }
    if (newPw !== newPw2) { setErr('비밀번호가 서로 일치하지 않습니다.'); return }
    changePassword(me!.id, newPw)
    nav('/')
  }

  if (me && !needChange) { nav('/'); return null }

  return (
    <div className="login-page">
      <div className="login-brand">
        <span className="spark" style={{ top: '12%', left: '10%' }}>✦</span>
        <span className="spark" style={{ bottom: '18%', right: '12%' }}>✦</span>
        <span className="spark" style={{ top: '30%', right: '24%', fontSize: 26 }}>✦</span>
        <h1>Thank you,<br />CERAGEM!</h1>
        <p className="slogan">우리는 세상에서 고객에게 '고맙다'는 말을<br />가장 많이 듣는 파트너가 된다!</p>
      </div>
      <div className="login-form-side">
        <div className="login-card">
          {!needChange ? (
            <>
              <h2>로그인</h2>
              <p className="muted" style={{ marginTop: 6, fontSize: 14 }}>사번 또는 이름으로 로그인하세요.</p>
              <div className="field">
                <label>사번 / 이름</label>
                <input type="text" value={id} onChange={e => setId(e.target.value)} placeholder="예: 100001 또는 이동현" onKeyDown={e => e.key === 'Enter' && submit()} />
              </div>
              <div className="field">
                <label>비밀번호</label>
                <input type="password" value={pw} onChange={e => setPw(e.target.value)} placeholder="비밀번호" onKeyDown={e => e.key === 'Enter' && submit()} />
              </div>
              {err && <div className="error-msg">{err}</div>}
              <div style={{ marginTop: 22 }}>
                <button className="btn btn-primary btn-block" onClick={submit}>로그인</button>
              </div>
              <p className="hint" style={{ marginTop: 14 }}>비밀번호를 잊으셨다면 세라제머육성팀(관리자)에게 초기화를 요청해주세요.</p>
              <p className="hint">데모 계정 — 관리자: 이동현 / 1234 · 일반: 김소영 / 0000</p>
            </>
          ) : (
            <>
              <h2>비밀번호 변경</h2>
              <p className="muted" style={{ marginTop: 6, fontSize: 14 }}>초기 비밀번호(0000)로 로그인하셨어요.<br />안전을 위해 새 비밀번호를 설정해주세요.</p>
              <div className="field">
                <label>새 비밀번호</label>
                <input type="password" value={newPw} onChange={e => setNewPw(e.target.value)} />
              </div>
              <div className="field">
                <label>새 비밀번호 확인</label>
                <input type="password" value={newPw2} onChange={e => setNewPw2(e.target.value)} onKeyDown={e => e.key === 'Enter' && submitChange()} />
              </div>
              {err && <div className="error-msg">{err}</div>}
              <div style={{ marginTop: 22 }}>
                <button className="btn btn-primary btn-block" onClick={submitChange}>변경하고 시작하기</button>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  )
}
