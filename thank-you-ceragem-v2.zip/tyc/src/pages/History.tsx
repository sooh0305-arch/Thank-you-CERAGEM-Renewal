import { useState } from 'react'
import { useDB, givenThisMonth, receivedThisMonth, honorThisQuarter, rewardBalance, requestExchange, quarterLabel } from '../store/store'
import { Reveal, ValueTag, fmt, fmtDate, Toast } from '../components/common'

export default function History() {
  const db = useDB()
  const me = db.users.find(u => u.id === db.sessionUserId)!
  const [exPts, setExPts] = useState(1000)
  const [msg, setMsg] = useState('')
  const [err, setErr] = useState('')

  const received = db.praises.filter(p => p.receiverId === me.id && !p.hidden).sort((a, b) => b.createdAt.localeCompare(a.createdAt))
  const sent = db.praises.filter(p => p.senderId === me.id).sort((a, b) => b.createdAt.localeCompare(a.createdAt))
  const exchanges = db.exchanges.filter(e => e.userId === me.id).sort((a, b) => b.requestedAt.localeCompare(a.requestedAt))
  const reward = rewardBalance(me.id)

  const doExchange = () => {
    const r = requestExchange(me.id, exPts)
    if (!r.ok) { setErr(r.error!); return }
    setErr('')
    setMsg('교환 신청이 접수됐어요. 관리자 승인 후 지급됩니다.')
    setTimeout(() => setMsg(''), 2500)
  }

  const statusClass = (s: string) => s === '대기' ? 'wait' : s === '반려' ? 'deny' : 'done'

  return (
    <>
      <section className="section" style={{ paddingTop: 56 }}>
        <div className="wrap">
          <span className="eyebrow">My History</span>
          <h1 className="display" style={{ fontSize: 'clamp(30px,4.6vw,48px)', marginTop: 10 }}>{me.name}님의 기록</h1>

          <Reveal>
            <div className="summary-hero" style={{ marginTop: 30 }}>
              <div className="cell"><div className="n">{fmt(givenThisMonth(me.id))}P</div><div className="l">이번 달 보낸 포인트</div></div>
              <div className="cell"><div className="n">{fmt(receivedThisMonth(me.id))}P</div><div className="l">이번 달 받은 포인트</div></div>
              <div className="cell"><div className="n red">{fmt(honorThisQuarter(me.id))}P</div><div className="l">{quarterLabel()} 누적 (시상 산정용)</div></div>
              <div className="cell"><div className="n red">{fmt(reward)}P</div><div className="l">교환 가능한 리워드</div></div>
            </div>
          </Reveal>
        </div>
      </section>

      {/* exchange */}
      <section className="section-tight" style={{ background: 'var(--white)', borderTop: '1.5px solid var(--line)', borderBottom: '1.5px solid var(--line)' }}>
        <div className="wrap" style={{ display: 'grid', gridTemplateColumns: '1fr auto', gap: 24, alignItems: 'center', flexWrap: 'wrap' }}>
          <div>
            <h2 className="display" style={{ fontSize: 24 }}>포인트 현금 교환</h2>
            <p className="muted" style={{ fontSize: 14, marginTop: 4 }}>1P = 1원 · 교환해도 분기 누적 포인트는 그대로 유지돼요.</p>
            {err && <div className="error-msg">{err}</div>}
          </div>
          <div style={{ display: 'flex', gap: 10, alignItems: 'center', flexWrap: 'wrap' }}>
            <div className="stepper" style={{ width: 210 }}>
              <button onClick={() => setExPts(p => Math.max(100, p - 100))}>−</button>
              <div className="val">{fmt(exPts)} P</div>
              <button onClick={() => setExPts(p => Math.min(reward, p + 100))}>＋</button>
            </div>
            <button className="btn btn-primary" disabled={exPts > reward || exPts <= 0} onClick={doExchange}>
              {fmt(exPts)}원으로 교환 신청
            </button>
          </div>
        </div>
      </section>

      {/* received */}
      <section className="section">
        <div className="wrap">
          <h2 className="display" style={{ fontSize: 28 }}>받은 칭찬 <span className="muted" style={{ fontSize: 16, fontWeight: 700 }}>{received.length}건</span></h2>
          <div className="list-plain" style={{ marginTop: 20 }}>
            {received.length === 0 && <div className="row-card muted">아직 받은 칭찬이 없어요. 곧 도착할 거예요!</div>}
            {received.map(p => (
              <div className="row-card" key={p.id}>
                <div style={{ flex: 1, minWidth: 240 }}>
                  <div style={{ fontSize: 15 }}>“{p.message}”</div>
                  <div style={{ display: 'flex', gap: 10, marginTop: 8, alignItems: 'center', flexWrap: 'wrap' }}>
                    <ValueTag no={p.valueNo} />
                    <span className="muted" style={{ fontSize: 12.5 }}>{fmtDate(p.createdAt)} · 익명의 동료</span>
                  </div>
                </div>
                <div className="pt-chip">+{fmt(p.points)}P</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* sent */}
      <section className="section" style={{ paddingTop: 0 }}>
        <div className="wrap">
          <h2 className="display" style={{ fontSize: 28 }}>보낸 칭찬 <span className="muted" style={{ fontSize: 16, fontWeight: 700 }}>{sent.length}건</span></h2>
          <div className="list-plain" style={{ marginTop: 20 }}>
            {sent.length === 0 && <div className="row-card muted">아직 보낸 칭찬이 없어요. 첫 칭찬을 보내볼까요?</div>}
            {sent.map(p => {
              const r = db.users.find(u => u.id === p.receiverId)
              return (
                <div className="row-card" key={p.id}>
                  <div style={{ flex: 1, minWidth: 240 }}>
                    <div style={{ fontWeight: 800 }}>{r?.name} <span className="muted" style={{ fontWeight: 600, fontSize: 13 }}>{r?.dept}</span></div>
                    <div style={{ fontSize: 14.5, marginTop: 4 }}>“{p.message}”</div>
                    <div style={{ display: 'flex', gap: 10, marginTop: 8, alignItems: 'center', flexWrap: 'wrap' }}>
                      <ValueTag no={p.valueNo} />
                      <span className="muted" style={{ fontSize: 12.5 }}>{fmtDate(p.createdAt)}</span>
                    </div>
                  </div>
                  <div className="pt-chip">−{fmt(p.points)}P</div>
                </div>
              )
            })}
          </div>
        </div>
      </section>

      {/* exchanges */}
      <section className="section" style={{ paddingTop: 0 }}>
        <div className="wrap">
          <h2 className="display" style={{ fontSize: 28 }}>포인트 교환 내역</h2>
          <div className="list-plain" style={{ marginTop: 20 }}>
            {exchanges.length === 0 && <div className="row-card muted">교환 내역이 없어요.</div>}
            {exchanges.map(e => (
              <div className="row-card" key={e.id}>
                <div style={{ fontWeight: 800 }}>{fmt(e.points)}P → {fmt(e.points)}원</div>
                <div className="muted" style={{ fontSize: 13 }}>{fmtDate(e.requestedAt)} 신청</div>
                <span className={`status-tag ${statusClass(e.status)}`}>{e.status}</span>
              </div>
            ))}
          </div>
        </div>
      </section>
      {msg && <Toast text={msg} />}
    </>
  )
}
