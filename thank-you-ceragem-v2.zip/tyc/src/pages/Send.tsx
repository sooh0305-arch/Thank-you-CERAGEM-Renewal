import { useMemo, useState } from 'react'
import { useNavigate, useSearchParams } from 'react-router-dom'
import { useDB, giveRemaining, givenToPersonThisMonth, sendPraise } from '../store/store'
import { CERA_VALUES, PER_PERSON_CAP, MIN_SEND, STEP } from '../types'
import { fmt, Confetti, Toast } from '../components/common'

export default function Send() {
  const db = useDB()
  const nav = useNavigate()
  const [sp] = useSearchParams()
  const me = db.users.find(u => u.id === db.sessionUserId)!

  const [valueNo, setValueNo] = useState(Number(sp.get('value')) || 4)
  const [to, setTo] = useState(sp.get('to') ?? '')
  const [msg, setMsg] = useState('')
  const [points, setPoints] = useState(300)
  const [err, setErr] = useState('')
  const [sent, setSent] = useState(false)

  const remaining = giveRemaining(me.id)
  const v = CERA_VALUES.find(x => x.no === valueNo)!
  const personRemaining = useMemo(() => {
    if (!to) return PER_PERSON_CAP
    return PER_PERSON_CAP - givenToPersonThisMonth(me.id, to)
  }, [to, db.praises])
  const maxSend = Math.min(remaining, personRemaining)

  const submit = () => {
    if (!to) { setErr('받는 동료를 선택해주세요.'); return }
    const r = sendPraise(me.id, to, valueNo, msg, points)
    if (!r.ok) { setErr(r.error!); return }
    setErr('')
    setSent(true)
    setTimeout(() => nav('/feed'), 1800)
  }

  return (
    <section className="section" style={{ paddingTop: 56 }}>
      <div className="wrap" style={{ maxWidth: 880 }}>
        <span className="eyebrow">Send a High Five</span>
        <h1 className="display" style={{ fontSize: 'clamp(30px,4.6vw,48px)', marginTop: 10 }}>
          동료에게 <span style={{ color: 'var(--red)' }}>{v.title}</span> 칭찬 보내기
        </h1>
        <p className="muted" style={{ marginTop: 10 }}>{v.desc}</p>

        <div className="send-panel" style={{ marginTop: 32 }}>
          <div className="field">
            <label>세라제머십 가치 선택</label>
            <select value={valueNo} onChange={e => setValueNo(Number(e.target.value))}>
              {CERA_VALUES.map(cv => <option key={cv.no} value={cv.no}>{String(cv.no).padStart(2, '0')} · {cv.title} — {cv.short}</option>)}
            </select>
          </div>

          <div className="field">
            <label>받는 동료</label>
            <select value={to} onChange={e => { setTo(e.target.value); setErr('') }}>
              <option value="" disabled>이름 · 부서로 선택하세요</option>
              {db.users.filter(u => u.active && u.id !== me.id).map(u => (
                <option key={u.id} value={u.id}>{u.name} · {u.dept}</option>
              ))}
            </select>
            {to && <p className="hint">이 동료에게 이번 달 남은 한도: <b>{fmt(personRemaining)}P</b> / {fmt(PER_PERSON_CAP)}P</p>}
          </div>

          <div className="field">
            <label>칭찬 메시지 (10자 이상)</label>
            <textarea
              value={msg}
              onChange={e => setMsg(e.target.value)}
              maxLength={300}
              placeholder={`예: "${v.short}"의 순간이 떠올랐어요. 구체적으로 어떤 점이 고마웠는지 적어주세요.`}
            />
            <p className="hint" style={{ textAlign: 'right' }}>{msg.length} / 300자</p>
          </div>

          <div className="field">
            <label>보낼 포인트</label>
            <div className="stepper">
              <button aria-label="포인트 줄이기" onClick={() => setPoints(p => Math.max(MIN_SEND, p - STEP))}>−</button>
              <div className="val">{fmt(points)} P</div>
              <button aria-label="포인트 늘리기" onClick={() => setPoints(p => Math.min(Math.max(maxSend, MIN_SEND), p + STEP))}>＋</button>
            </div>
          </div>

          <div className="budget-bar">
            <div className="track"><div className="fill" style={{ width: `${(remaining / 5000) * 100}%` }} /></div>
            <div className="cap"><span>이번 달 남은 보내기 포인트</span><span><b style={{ color: 'var(--red)' }}>{fmt(remaining)}P</b> / 5,000P</span></div>
          </div>

          {err && <div className="error-msg">{err}</div>}

          <div style={{ marginTop: 22 }}>
            <button className="btn btn-primary btn-block" disabled={sent || points > maxSend} onClick={submit}>
              {sent ? '보냈어요! 🎉' : `${fmt(points)}P와 함께 칭찬 보내기`}
            </button>
          </div>
          {points > maxSend && <p className="error-msg">지금 보낼 수 있는 최대 포인트는 {fmt(Math.max(maxSend, 0))}P예요.</p>}
        </div>
      </div>
      {sent && <><Confetti /><Toast text="칭찬이 전달됐어요. 피드로 이동합니다!" /></>}
    </section>
  )
}
