import { useMemo, useState } from 'react'
import { useDB, sameMonth, honorThisQuarter, quarterLabel, adminResetPassword, adminToggleActive, adminAddUser, adminTogglePraiseHidden, adminSetExchangeStatus, adminMonthlyReset, adminCloseQuarter, givenThisMonth, rewardBalance, resetDemo } from '../store/store'
import { CERA_VALUES } from '../types'
import { fmt, fmtDate, valueOf, Toast } from '../components/common'

type Tab = '대시보드' | '사용자' | '칭찬내역' | '포인트교환' | '통계' | '설정'
const TABS: Tab[] = ['대시보드', '사용자', '칭찬내역', '포인트교환', '통계', '설정']

export default function Admin() {
  const db = useDB()
  const me = db.users.find(u => u.id === db.sessionUserId)!
  const [tab, setTab] = useState<Tab>('대시보드')
  const [toast, setToast] = useState('')
  const say = (t: string) => { setToast(t); setTimeout(() => setToast(''), 2200) }

  const monthPraises = db.praises.filter(p => sameMonth(p.createdAt))
  const valueCounts = useMemo(() => CERA_VALUES.map(v => ({ v, n: db.praises.filter(p => p.valueNo === v.no && !p.hidden).length })), [db.praises])
  const maxCount = Math.max(1, ...valueCounts.map(c => c.n))
  const ranked = useMemo(() => db.users.filter(u => u.active).map(u => ({ u, pt: honorThisQuarter(u.id) })).sort((a, b) => b.pt - a.pt), [db.users, db.praises])

  const [nuName, setNuName] = useState(''); const [nuDept, setNuDept] = useState(''); const [nuEmp, setNuEmp] = useState('')

  const csvDownload = () => {
    const rows = [['보낸사람', '받은사람', '가치', '메시지', '포인트', '일시'].join(',')]
    db.praises.forEach(p => {
      const s = db.users.find(u => u.id === p.senderId)?.name ?? ''
      const r = db.users.find(u => u.id === p.receiverId)?.name ?? ''
      rows.push([s, r, valueOf(p.valueNo).title, `"${p.message.replace(/"/g, '""')}"`, p.points, p.createdAt].join(','))
    })
    const blob = new Blob(['\ufeff' + rows.join('\n')], { type: 'text/csv' })
    const a = document.createElement('a')
    a.href = URL.createObjectURL(blob)
    a.download = 'praises.csv'
    a.click()
  }

  return (
    <section className="section" style={{ paddingTop: 48 }}>
      <div className="wrap">
        <span className="eyebrow">Admin Only</span>
        <h1 className="display" style={{ fontSize: 'clamp(28px,4vw,42px)', marginTop: 8 }}>관리자 콘솔</h1>

        <div className="admin-tabs">
          {TABS.map(t => <button key={t} className={tab === t ? 'on' : ''} onClick={() => setTab(t)}>{t}</button>)}
        </div>

        {tab === '대시보드' && (
          <>
            <div className="kpi-grid">
              <div className="kpi"><div className="n">{db.users.filter(u => u.active).length}</div><div className="l">활성 사용자</div></div>
              <div className="kpi"><div className="n">{fmt(monthPraises.reduce((s, p) => s + p.points, 0))}P</div><div className="l">이달 발송 포인트</div></div>
              <div className="kpi"><div className="n">{monthPraises.length}건</div><div className="l">이달 칭찬 건수</div></div>
              <div className="kpi"><div className="n">{ranked[0]?.u.name ?? '-'}</div><div className="l">{quarterLabel()} 1위</div></div>
            </div>
            <div className="table-wrap" style={{ marginTop: 20, padding: '24px 24px 12px' }}>
              <b>세라제머십 항목별 누적 칭찬</b>
              <div className="bar-chart">
                {valueCounts.map(({ v, n }) => (
                  <div className="bar-col" key={v.no}>
                    <div className="bar-v">{n}</div>
                    <div className="bar" style={{ height: `${(n / maxCount) * 78}%`, minHeight: 6 }} />
                    <div className="bar-l">{String(v.no).padStart(2, '0')}<br />{v.title}</div>
                  </div>
                ))}
              </div>
            </div>
          </>
        )}

        {tab === '사용자' && (
          <>
            <div className="table-wrap">
              <table className="data">
                <thead><tr><th>이름</th><th>부서</th><th>사번</th><th>이달 발송</th><th>리워드 잔액</th><th>분기 누적</th><th>상태</th><th>관리</th></tr></thead>
                <tbody>
                  {db.users.map(u => (
                    <tr key={u.id}>
                      <td><b>{u.name}</b>{u.role === 'admin' && ' 👑'}{u.mustChangePassword && <span className="status-tag wait" style={{ marginLeft: 6 }}>PW변경필요</span>}</td>
                      <td>{u.dept}</td><td>{u.empNo}</td>
                      <td>{fmt(givenThisMonth(u.id))}P</td>
                      <td>{fmt(rewardBalance(u.id))}P</td>
                      <td>{fmt(honorThisQuarter(u.id))}P</td>
                      <td>{u.active ? '활성' : <span style={{ color: 'var(--red)' }}>비활성</span>}</td>
                      <td style={{ whiteSpace: 'nowrap' }}>
                        <button className="btn btn-ghost btn-sm" onClick={() => { adminResetPassword(me.id, u.id); say(`${u.name}님 비밀번호를 0000으로 초기화했어요.`) }}>PW초기화</button>{' '}
                        <button className="btn btn-ghost btn-sm" onClick={() => adminToggleActive(me.id, u.id)}>{u.active ? '비활성화' : '활성화'}</button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div className="row-card" style={{ marginTop: 16, gap: 10 }}>
              <b>사용자 등록</b>
              <input className="search-input" placeholder="이름" value={nuName} onChange={e => setNuName(e.target.value)} />
              <input className="search-input" placeholder="부서" value={nuDept} onChange={e => setNuDept(e.target.value)} />
              <input className="search-input" placeholder="사번" value={nuEmp} onChange={e => setNuEmp(e.target.value)} />
              <button className="btn btn-primary btn-sm" disabled={!nuName || !nuDept || !nuEmp} onClick={() => { adminAddUser(me.id, nuName, nuDept, nuEmp); setNuName(''); setNuDept(''); setNuEmp(''); say('사용자를 등록했어요. 초기 비밀번호는 0000입니다.') }}>등록</button>
            </div>
          </>
        )}

        {tab === '칭찬내역' && (
          <>
            <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: 12 }}>
              <button className="btn btn-ghost btn-sm" onClick={csvDownload}>CSV 다운로드</button>
            </div>
            <div className="table-wrap">
              <table className="data">
                <thead><tr><th>일시</th><th>보낸 사람</th><th>받은 사람</th><th>가치</th><th>메시지</th><th>포인트</th><th>공개</th></tr></thead>
                <tbody>
                  {db.praises.map(p => {
                    const s = db.users.find(u => u.id === p.senderId); const r = db.users.find(u => u.id === p.receiverId)
                    return (
                      <tr key={p.id} style={p.hidden ? { opacity: 0.45 } : undefined}>
                        <td>{fmtDate(p.createdAt)}</td><td>{s?.name}</td><td><b>{r?.name}</b></td>
                        <td>{String(p.valueNo).padStart(2, '0')} {valueOf(p.valueNo).title}</td>
                        <td style={{ maxWidth: 320 }}>{p.message}</td>
                        <td>{fmt(p.points)}P</td>
                        <td><button className="btn btn-ghost btn-sm" onClick={() => adminTogglePraiseHidden(me.id, p.id)}>{p.hidden ? '공개' : '비공개'}</button></td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
          </>
        )}

        {tab === '포인트교환' && (
          <div className="table-wrap">
            <table className="data">
              <thead><tr><th>신청일</th><th>신청자</th><th>포인트</th><th>금액</th><th>상태</th><th>처리</th></tr></thead>
              <tbody>
                {db.exchanges.map(e => {
                  const u = db.users.find(x => x.id === e.userId)
                  return (
                    <tr key={e.id}>
                      <td>{fmtDate(e.requestedAt)}</td><td><b>{u?.name}</b> <span className="muted">{u?.dept}</span></td>
                      <td>{fmt(e.points)}P</td><td>{fmt(e.points)}원</td>
                      <td><span className={`status-tag ${e.status === '대기' ? 'wait' : e.status === '반려' ? 'deny' : 'done'}`}>{e.status}</span></td>
                      <td style={{ whiteSpace: 'nowrap' }}>
                        {e.status === '대기' && <>
                          <button className="btn btn-ghost btn-sm" onClick={() => { adminSetExchangeStatus(me.id, e.id, '승인'); say('승인 처리했어요.') }}>승인</button>{' '}
                          <button className="btn btn-ghost btn-sm" onClick={() => { adminSetExchangeStatus(me.id, e.id, '반려'); say('반려 처리했어요. 포인트는 반환됩니다.') }}>반려</button>
                        </>}
                        {e.status === '승인' && <button className="btn btn-primary btn-sm" onClick={() => { adminSetExchangeStatus(me.id, e.id, '지급완료'); say('지급완료 처리했어요.') }}>지급완료</button>}
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        )}

        {tab === '통계' && (
          <div className="table-wrap" style={{ padding: '24px 24px 12px' }}>
            <b>세라제머십 항목별 칭찬 건수 (전체 기간)</b>
            <div className="bar-chart">
              {valueCounts.map(({ v, n }) => (
                <div className="bar-col" key={v.no}>
                  <div className="bar-v">{n}</div>
                  <div className="bar" style={{ height: `${(n / maxCount) * 78}%`, minHeight: 6 }} />
                  <div className="bar-l">{String(v.no).padStart(2, '0')}<br />{v.title}</div>
                </div>
              ))}
            </div>
            <div className="table-wrap" style={{ border: 'none' }}>
              <table className="data">
                <thead><tr><th>순위</th><th>이름</th><th>부서</th><th>{quarterLabel()} 누적</th></tr></thead>
                <tbody>
                  {ranked.map((r, i) => <tr key={r.u.id}><td><b>{i + 1}</b></td><td>{r.u.name}</td><td>{r.u.dept}</td><td>{fmt(r.pt)}P</td></tr>)}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {tab === '설정' && (
          <>
            <div className="danger-zone">
              <h4>⚠️ 위험 구역 — 실행 전 반드시 확인하세요</h4>
              <div style={{ display: 'flex', gap: 12, marginTop: 16, flexWrap: 'wrap' }}>
                <button className="btn btn-primary" onClick={() => { if (confirm('전 사용자의 이번 달 보내기 포인트를 5,000P로 초기화 처리(기록)할까요?')) { adminMonthlyReset(me.id); say('월별 초기화를 기록했어요.') } }}>월별 5,000P 초기화 실행</button>
                <button className="btn btn-ghost" onClick={() => { const w = ranked.slice(0, 2).map(r => r.u.name); if (confirm(`분기를 마감하고 땡큐 세라제머를 선정할까요?\n선정 대상: ${w.join(', ')}`)) { adminCloseQuarter(me.id, w); say('분기 마감을 기록했어요.') } }}>분기 마감 · 땡큐 세라제머 선정</button>
                <button className="btn btn-ghost" onClick={() => { if (confirm('데모 데이터를 초기 상태로 되돌릴까요?')) resetDemo() }}>데모 데이터 리셋</button>
              </div>
            </div>
            <div style={{ marginTop: 24 }}>
              <b>시스템 로그</b>
              <div style={{ marginTop: 10 }}>
                {db.logs.length === 0 && <div className="log-line">기록된 로그가 없습니다.</div>}
                {db.logs.map(l => {
                  const by = db.users.find(u => u.id === l.by)?.name ?? l.by
                  return <div className="log-line" key={l.id}>{new Date(l.at).toLocaleString('ko-KR')} · {l.action} · 처리자 {by}</div>
                })}
              </div>
            </div>
          </>
        )}
      </div>
      {toast && <Toast text={toast} />}
    </section>
  )
}
