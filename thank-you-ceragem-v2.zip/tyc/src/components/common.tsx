import { useEffect, useRef, useState } from 'react'
import { NavLink, useNavigate } from 'react-router-dom'
import { useDB, logout, markPraiseRead, markAllRead, giveRemaining, rewardBalance } from '../store/store'
import { CERA_VALUES } from '../types'

export function fmt(n: number) { return n.toLocaleString('ko-KR') }
export function fmtDate(iso: string) {
  const d = new Date(iso)
  return `${d.getMonth() + 1}.${d.getDate()}`
}
export function valueOf(no: number) { return CERA_VALUES.find(v => v.no === no)! }

export function ValueTag({ no }: { no: number }) {
  const v = valueOf(no)
  return <span className="value-tag">가치 {v.no} · {v.title}</span>
}

export function TopNav() {
  const db = useDB()
  const nav = useNavigate()
  const me = db.users.find(u => u.id === db.sessionUserId)
  const [open, setOpen] = useState(false)
  const ref = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const h = (e: MouseEvent) => { if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false) }
    document.addEventListener('mousedown', h)
    return () => document.removeEventListener('mousedown', h)
  }, [])

  if (!me) return null
  const unread = db.praises.filter(p => p.receiverId === me.id && !p.readByReceiver && !p.hidden)

  return (
    <header className="topnav">
      <div className="topnav-inner">
        <NavLink to="/" className="brand">Thank you, <em>CERAGEM!</em></NavLink>
        <nav>
          <NavLink to="/" end>홈</NavLink>
          <NavLink to="/send">칭찬 보내기</NavLink>
          <NavLink to="/feed">칭찬 피드</NavLink>
          <NavLink to="/history">마이 히스토리</NavLink>
          <NavLink to="/ranking">랭킹</NavLink>
          <NavLink to="/guide">가이드</NavLink>
          {me.role === 'admin' && <NavLink to="/admin">관리자</NavLink>}
        </nav>
        <div className="nav-right">
          <div className="bell-wrap" ref={ref}>
            <button className="bell-btn" aria-label="알림" onClick={() => setOpen(o => !o)}>
              🔔{unread.length > 0 && <span className="bell-dot">{unread.length}</span>}
            </button>
            {open && (
              <div className="bell-panel">
                {unread.length === 0 && <div className="bell-empty">새 알림이 없어요.<br />오늘은 먼저 칭찬을 보내볼까요?</div>}
                {unread.map(p => (
                  <div className="bell-item" key={p.id}>
                    <div className="t">💌 <b>{fmt(p.points)}P 칭찬</b>이 도착했어요<br /><span className="muted">{valueOf(p.valueNo).title} · {fmtDate(p.createdAt)}</span></div>
                    <button onClick={() => markPraiseRead(p.id)}>확인</button>
                  </div>
                ))}
                {unread.length > 1 && (
                  <div className="bell-item"><button onClick={() => markAllRead(me.id)}>모두 확인</button></div>
                )}
              </div>
            )}
          </div>
          <div className="points-pill" title="이번 달 보낼 수 있는 포인트 / 교환 가능한 포인트">
            <span className="hide-m">보내기</span> <strong>{fmt(giveRemaining(me.id))}P</strong>
            <span style={{ color: 'var(--line)' }}>|</span>
            <span className="hide-m">리워드</span> <strong>{fmt(rewardBalance(me.id))}P</strong>
          </div>
          <button className="btn btn-ghost btn-sm" onClick={() => { logout(); nav('/login') }}>로그아웃</button>
        </div>
      </div>
    </header>
  )
}

export function SiteFooter() {
  return (
    <footer className="site">
      <div className="wrap">
        <div className="mascot">🙌</div>
        <div className="msg">오늘 고마웠던 동료가 떠올랐다면,<br />지금이 보낼 타이밍이에요.</div>
        <div className="links">
          <a href="#/guide">이용 가이드</a>
          <a href="#/feed">칭찬 피드</a>
          <a href="#/ranking">이번 분기 랭킹</a>
          <span>문의: 세라제머육성팀</span>
        </div>
        <div className="legal">© 2026 CERAGEM · Thank you, CERAGEM은 세라젬 임직원 전용 서비스입니다.</div>
      </div>
    </footer>
  )
}

/** scroll reveal wrapper */
export function Reveal({ children, className = '' }: { children: React.ReactNode; className?: string }) {
  const ref = useRef<HTMLDivElement>(null)
  useEffect(() => {
    const el = ref.current
    if (!el) return
    const io = new IntersectionObserver(([e]) => { if (e.isIntersecting) { el.classList.add('in'); io.disconnect() } }, { threshold: 0.12 })
    io.observe(el)
    return () => io.disconnect()
  }, [])
  return <div ref={ref} className={`reveal ${className}`}>{children}</div>
}

export function Toast({ text }: { text: string }) {
  return <div className="toast">{text}</div>
}

export function Confetti() {
  const pieces = ['🎉', '💌', '⭐', '👏', '🧡']
  return (
    <>
      {Array.from({ length: 14 }).map((_, i) => (
        <span key={i} className="confetti-piece" style={{ left: `${6 + i * 6.5}%`, animationDelay: `${(i % 5) * 0.12}s` }}>
          {pieces[i % pieces.length]}
        </span>
      ))}
    </>
  )
}
